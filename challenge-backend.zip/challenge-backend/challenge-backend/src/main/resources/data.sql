insert into dimension(code, weight, height, width, length) values (10,10.5, 10.5, 10.5, 10.5);
insert into dimension(code, weight, height, width, length) values (20,10.5, 10.5, 10.5, 10.5);
insert into dimension(code, weight, height, width, length) values (30,10.5, 10.5, 10.5, 10.5);
insert into dimension(code, weight, height, width, length) values (40,10.5, 10.5, 10.5, 10.5);
insert into dimension(code, weight, height, width, length) values (50,10.5, 10.5, 10.5, 10.5);

insert into itens(code, name, date, dimension_code) values(1, 'Impressora', '2016-10-05T14:30:37.040Z', 10);
insert into itens(code, name, date, dimension_code) values(2, 'Fifa2017', '2016-10-05T14:30:37.040Z', 20);
insert into itens(code, name, date, dimension_code) values(3, 'Notebook', '2016-10-05T14:30:37.040Z', 30);
insert into itens(code, name, date, dimension_code) values(4, 'Mouse', '2016-10-05T14:30:37.040Z', 40);
insert into itens(code, name, date, dimension_code) values(5, 'Celular', '2016-10-05T14:30:37.040Z', 50);