package com.william.challengebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
