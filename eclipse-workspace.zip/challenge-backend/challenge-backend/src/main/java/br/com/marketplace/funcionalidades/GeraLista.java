package br.com.marketplace.funcionalidades;

import java.sql.SQLException;
import java.util.List;

import br.com.marketplace.jdbc.dao.ProdutoDao;
import br.com.marketplace.jdbc.modelo.Produtos;

public class GeraLista {
	
	public static void main(String[] args) throws SQLException {
		ProdutoDao dao = new ProdutoDao();
		Produtos smtp = new Produtos();
		List<Produtos> produtos = dao.getLista();
		
		
		for (Produtos produto : produtos) {
			System.out.println("Código: " + produto.getCode());
			System.out.println("Nome: " + produto.getName());
			System.out.println("Data: " + produto.getDate().getTime());
			System.out.println("Weight: " + produto.getWeight());
			System.out.println("Height: " + produto.getHeight());
			System.out.println("Width: " + produto.getWidth());
			System.out.println("Length: " + produto.getLength()+ "\n");		
	    }
	}
}
