package br.com.marketplace.funcionalidades;

import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.time.LocalDateTime;

import br.com.marketplace.jdbc.dao.ProdutoDao;
import br.com.marketplace.jdbc.modelo.Produtos;

public class Adiciona {
	public static void main(String[] args) {
		
		// Passando as informações para o inserção
		Produtos produto = new Produtos();
		produto.setCode(9);
		produto.setName("Mesa");
		/*LocalDateTime localDate = LocalDateTime.now();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
		produto.setDate(dtf.format(localDate));*/
		produto.setDate(Calendar.getInstance());
		produto.setWeight(10.5);
		produto.setHeight(10.5);
		produto.setWidth(10.5);
		produto.setLength(10.5);

		//Vai gravar os dados nessa conexão
		ProdutoDao dao = new ProdutoDao();
		
		// Chama o método adiciona
		dao.adiciona(produto);
		System.out.println("Produto gravado com sucesso!");
	
	}
}