package br.com.marketplace.jdbc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.marketplace.jdbc.ConnectionFactory;
import br.com.marketplace.jdbc.modelo.Produtos;

public class ProdutoDao {

	// a conexão com o banco de dados
	private Connection connection;

	public ProdutoDao() {
		this.connection = new ConnectionFactory().getConnection();
	}

	// Adiciona os produtos
	public void adiciona(Produtos produto) {
		String sql = "insert into produtos "
				+ "(prod_code,prod_name,prod_date,prod_weight,prod_height,prod_width,prod_length)"
				+ " values (?,?,?,?,?,?,?)";
		try {
			// prepared statement para inserção
			PreparedStatement stmt = connection.prepareStatement(sql);

			// Seta os valores de cada parâmetro
			stmt.setInt(1, produto.getCode());
			stmt.setString(2, produto.getName());
			/*LocalDateTime localDate = LocalDateTime.now();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:mm:ss");
			stmt(3, produto.setDate(dtf.format(localDate)));*/
			stmt.setDate(3, new Date(produto.getDate().getTimeInMillis()));
			stmt.setDouble(4, produto.getWeight());
			stmt.setDouble(5, produto.getHeight());
			stmt.setDouble(6, produto.getWidth());
			stmt.setDouble(7, produto.getLength());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	//Lista produtos
	public List<Produtos> getLista() {
		try {
			List<Produtos> contatos = new ArrayList<Produtos>();

			PreparedStatement stmt = this.connection.prepareStatement("select * from produtos");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

		     	// criando o objeto Contato
				Produtos produto = new Produtos();
				produto.setCode(rs.getInt("prod_code"));
				produto.setName(rs.getString("prod_name"));
				
				//Formatando a data
				Calendar data = Calendar.getInstance();
				data.setTime(rs.getDate("prod_date"));
				produto.setDate(data);
				
				produto.setWeight(rs.getDouble("prod_weight"));
				produto.setHeight(rs.getDouble("prod_height"));
				produto.setWidth(rs.getDouble("prod_width"));
				produto.setLength(rs.getDouble("prod_length"));
				
				// Adicionando as informações na lista
				contatos.add(produto);
			}
			rs.close();
			stmt.close();
			return contatos;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}